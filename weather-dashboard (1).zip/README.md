# Weather Dashboard

React.js app to display live weather info using OpenWeatherMap API.